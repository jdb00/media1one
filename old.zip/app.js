const tl = gsap.timeline({defaults: {ease: 'power1.out'}});

var video = $('video')


tl.to('.text', {y: '0%', duration: 1, stagger: 1, onComplete: flash})




function playVideo(){
    $('video').get(0).play();
}

function flash(){
    $('.text').addClass('blink')
}

function playTimeline(){
    tl.to('.slider', {y: "-100%", duration: .75, delay: .75})
    .to('.intro', {y: "-100%", duration: 1}, "-=1")
    .fromTo('nav', {opacity: 0}, {opacity: 1, duration: 1, onComplete: playVideo})
    .fromTo('video', {opacity: 0}, {opacity: 1, duration: 1})
    .fromTo('.big-text', {opacity: 0}, {opacity: 1, duration: 1}, '-=1')
    .to('.big-text', {opacity: 0, duration: 1})
}

$('video').on('ended', function(){
    tl.fromTo('video',{opacity:1}, {opacity: 0, duration: 1})
    .fromTo('.big-text',{opacity:0}, {opacity: 1, duration: 1})
    .fromTo('.gallery', {opacity:'0'}, {opacity:'1', duration: 5})
    .fromTo('.contact', {opacity:'0'}, {opacity:'1', duration: 5}, '-=5')


})

$('body').on('click', function(){
    $('video').prop('muted', false)
})

var video = document.querySelector('video');


video.addEventListener('canplaythrough', function() {
    playTimeline()
 }, false);
 


 


