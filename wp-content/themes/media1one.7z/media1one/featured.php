<section class="featured">
    <svg class="section-decor" viewBox="0 0 100 100" preserveAspectRatio="none">
        <!-- <polygon points="0,100 100,0 100,100" /> -->
        <polygon points="100,0 0,100 0,0" />
    </svg>
    <div class="featured-wrap">
        <h2>Featured Shoots</h2>
        <div class="featured-container">
            <div class="feature">
                <div class="swiper-container-2">
                    <!-- Additional required wrapper -->
                    <div class="swiper-wrapper">
                        <!-- Slides -->
                        <div class="swiper-slide">
                            <img data-src="./assets/images/Stealth-Seat-Covers-Custom-Waterproof-4x4-Seat-Covers-New-Zealand-6.jpg" class="swiper-lazy" alt="">
                            <div class="swiper-lazy-preloader swiper-lazy-preloader-white"></div>
                        </div>
                        <div class="swiper-slide">
                            <img data-src="./assets/images/Stealth-Seat-Covers-Custom-Waterproof-4x4-Seat-Covers-New-Zealand-6.jpg" class="swiper-lazy" alt="">
                            <div class="swiper-lazy-preloader swiper-lazy-preloader-white"></div>
                        </div>
                    </div>
                    <!-- Add Pagination -->
                    <div class="swiper-pagination-2"></div>
                </div> 
                <div class="text-wrap">
                    <div class="feature-text">
                        <h3>Stealth Seat Covers</h3>
                        <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Id et deserunt sequi quos, est molestiae dolorem tempora voluptates numquam dignissimos a laborum eos adipisci officia?</p>
                        <a href="">stealthseatcovers.co.nz</a>
                    </div>
                </div>
            </div>
            <div class="feature">
                <div class="swiper-container-2">
                    <!-- Additional required wrapper -->
                    <div class="swiper-wrapper">
                        <!-- Slides -->
                        <div class="swiper-slide">
                            <img data-src="./assets/images/Stealth-Seat-Covers-Custom-Waterproof-4x4-Seat-Covers-New-Zealand-6.jpg" class="swiper-lazy" alt="">
                            <div class="swiper-lazy-preloader swiper-lazy-preloader-white"></div>
                        </div>
                    </div>
                    <!-- Add Pagination -->
                    <div class="swiper-pagination-2"></div>
                </div> 
                <div class="text-wrap">
                    <div class="feature-text">
                        <h3>Stealth Seat Covers</h3>
                        <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Id et deserunt sequi quos, est molestiae dolorem tempora voluptates numquam dignissimos a laborum eos adipisci officia?</p>
                        <a href="">stealthseatcovers.co.nz</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>