<?php get_header()?>
<?php get_template_part('swiper')?>
<?php get_template_part('h-gallery')?>
<?php get_template_part('services')?>
<?php get_template_part('featured')?>
<?php get_footer()?>

