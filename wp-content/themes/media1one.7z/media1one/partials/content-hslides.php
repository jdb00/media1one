<div class="swiper-slide">
    <img data-src="<?php the_field('image')?>" class="swiper-lazy">
    <div class="swiper-lazy-preloader swiper-lazy-preloader-white"></div>
</div> 