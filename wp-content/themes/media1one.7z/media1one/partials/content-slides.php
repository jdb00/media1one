<?php
    global $active_class;
    $link = get_field('url');
?>    

<div class="swiper-slide">
    <img data-src="<?php the_field('image')?>" class="swiper-lazy" alt="">
    <div class="swiper-lazy-preloader swiper-lazy-preloader-white"></div>
</div>